# Proyecto-final

Este reposutorio trata de que los estudiantes pongan los resultados de los examenes y le tiran de una vez el promedio, facilitando muchas cosas al profesor, ahorrandole tiempo y tambien haciendolo mas facil

Codigo:

![image](https://github.com/user-attachments/assets/d13d2d97-3234-4bf7-8b22-6f11a12869e0)

La primera parte del codigo le pide el nombre de estudiante para saber quien es, le pide el numero de examenes para saber cuantos examenes realizo para poder hacer las operaciones correspondientes, la variante de Suma_examenes es para realizar la operacion y por ultimo la variable Resultado_final es para el promedio

![image](https://github.com/user-attachments/assets/9781109f-ca40-4106-a4e9-a8072f4d4daf)

La suguiente parte de codigo se basa dependiendo de los examenes realizados si el estudiante realizo 5, usa el if del 5 y hace la operacion correspodiente 



