Nombre=input("Digite su nombre: ")
Examenes= int(input("Digite el numero de examenes que realizo: "))
Suma_examenes=int
Resultado_final=float


if(Examenes == 2):
   Nota1=int(input("Digite la nota de su primer examen: "))
   Nota2=int(input("Digite la nota de su segundo examen: "))
   Suma_examenes= Nota1 + Nota2 
   Resultado_final=Suma_examenes / 2
   if(Resultado_final >= 70):
       print(Nombre, +(float (Resultado_final)), (str( "estas aprobado felicidades.")), )
   elif(Resultado_final >=60  <=70):
        print(Nombre, +(float (Resultado_final)), (str( "estas aplazado.")), )
   else:
     print(Nombre, +(float (Resultado_final)), (str( "estas reprobado.")), )
     
if(Examenes == 3):
   Nota1=int(input("Digite la nota de su primer examen: "))
   Nota2=int(input("Digite la nota de su segundo examen: "))
   Nota3=int(input("Digite la nota de su tercero examen: "))
   Suma_examenes= Nota1 + Nota2 + Nota3 
   Resultado_final=Suma_examenes / 3
   if(Resultado_final >= 70):
       print(Nombre, +(float (Resultado_final)), (str( "estas aprobado felicidades.")), )
   elif(Resultado_final >=60  <=70):
        print(Nombre, +(float (Resultado_final)), (str( "estas aplazado.")), )
   else:
     print(Nombre, +(float (Resultado_final)), (str( "estas reprobado.")), )
     
if(Examenes == 4):
   Nota1=int(input("Digite la nota de su primer examen: "))
   Nota2=int(input("Digite la nota de su segundo examen: "))
   Nota3=int(input("Digite la nota de su tercero examen: "))
   Nota4=int(input("Digite la nota de su Cuarto examen: "))
   Suma_examenes= Nota1 + Nota2 + Nota3 + Nota4
   Resultado_final=Suma_examenes / 4
   if(Resultado_final >= 70):
       print(Nombre, +(float (Resultado_final)), (str( "estas aprobado felicidades.")), )
   elif(Resultado_final >=60  <=70):
        print(Nombre, +(float (Resultado_final)), (str( "estas aplazado.")), )
   else:
     print(Nombre, +(float (Resultado_final)), (str( "estas reprobado.")), )

if(Examenes == 5):
   Nota1=int(input("Digite la nota de su primer examen: "))
   Nota2=int(input("Digite la nota de su segundo examen: "))
   Nota3=int(input("Digite la nota de su tercero examen: "))
   Nota4=int(input("Digite la nota de su Cuarto examen: "))
   Nota5=int(input("Digite la nota de su quinto examen: "))
   Suma_examenes= Nota1 + Nota2 + Nota3 + Nota5
   Resultado_final=Suma_examenes / 5
   if(Resultado_final >= 70):
       print(Nombre, +(float (Resultado_final)), (str( "estas aprobado felicidades.")), )
   elif(Resultado_final >=60  <=70):
        print(Nombre, +(float (Resultado_final)), (str( "estas aplazado.")), )
   else:
     print(Nombre, +(float (Resultado_final)), (str( "estas reprobado.")), )
  
if(Examenes == 6):
   Nota1=int(input("Digite la nota de su primer examen: "))
   Nota2=int(input("Digite la nota de su segundo examen: "))
   Nota3=int(input("Digite la nota de su tercero examen: "))
   Nota4=int(input("Digite la nota de su Cuarto examen: "))
   Nota5=int(input("Digite la nota de su quinto examen: "))
   Nota6=int(input("Digite la nota de su sexto examen: "))
   Suma_examenes= Nota1 + Nota2 + Nota3 + Nota4
   Resultado_final=Suma_examenes / 6
   if(Resultado_final >= 70):
       print(Nombre, +(float (Resultado_final)), (str( "estas aprobado felicidades.")), )
   elif(Resultado_final >=60  <=70):
        print(Nombre, +(float (Resultado_final)), (str( "estas aplazado.")), )
   else:
     print(Nombre, +(float (Resultado_final)), (str( "estas reprobado.")), )
     

   